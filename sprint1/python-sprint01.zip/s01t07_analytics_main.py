# s01t07_analytics_main.py

from analytics import print_str_analytics


if __name__ == '__main__':
    print_str_analytics('We are three wise men!')
    print_str_analytics('NI')
