my_number = 1
print(my_number)
# replace me with code
print(my_number)
