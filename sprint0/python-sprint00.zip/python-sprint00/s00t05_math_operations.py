a = input('Enter the first number: ')
b = input('Enter the second number: ')
a = int(a)
b = int(b)

# write your code here