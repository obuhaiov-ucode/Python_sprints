result = float(a + b)
result = ...(c - b)
result = ...(c) + ...(b)
result = ...(a - a)