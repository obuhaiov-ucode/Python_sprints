from multiplier import multiplier


if __name__ == '__main__': 
    test_1 = [2.72, 43, 4]
    test_2 = [22, 3.04, 26]
    test_3 = [23, 5, 3.36]

    print(multiplier(test_1))
    print('***')

    print(multiplier(test_2))
    print('***')

    print(multiplier(test_3))
    print('***')
