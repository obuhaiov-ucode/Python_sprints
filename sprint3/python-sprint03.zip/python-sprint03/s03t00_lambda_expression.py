n = int(input('n: '))
a = int(input('a: '))
b = int(input('b: '))

# Only edit the following line
result = (lambda ...)(...)

print(result)
